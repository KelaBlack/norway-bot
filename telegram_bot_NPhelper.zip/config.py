# config.py

BOT_TOKEN = "7977879088:AAF0uwNN0owwG-y8IvFLuPFpszMfHt3EZmM"
SPREADSHEET_NAME = "1owz37z-Zl63b_9Sq6NCHbNwZ7CGj2W8_PTg0supIXiY"  # Это ID, а не имя
CREDENTIALS_PATH = r"D:\Работа\bot\credentials.json"  # путь до JSON-файла с ключом Google

# ID администратора Telegram для уведомлений
ADMIN_CHAT_ID = 379825375  # заменишь на свой chat_id позже